# Change Log
<pre>

v1.1.1  Replaced deprecated backgroundSessionConfiguration with backgroundSessionConfigurationWithIdentifier. [MOD-1892]

v1.1.0  Rebuilt for 64-bit using Hyperloop from May 12, 2014 (git hash b4dc4ae44d951ad5c65860543ac026fb54b419d1) [TIMOB-18090]

v1.0.1  Rebuilt using Hyperloop from May 12, 2014 (git hash b4dc4ae44d951ad5c65860543ac026fb54b419d1)

v1.0    Initial Release
